# Correctif sous-titrage vocal Android TV – V2

## Problèmes ciblés
- Aucun PCM reçu sur certaines Android TV : le passthrough HDMI pouvait contourner les AudioProcessors Media3.
- Crash lors du chargement du modèle Sherpa quand la mémoire libre était trop faible.
- Rechargements concurrents du modèle lors de changements de réglages.
- Retard variable des sous-titres causé par l'ancrage de synchronisation au moment du décodage CPU.
- Accumulation de blocs audio sur les TV lentes.
- Résultats de traduction pouvant appartenir à une phrase précédente.
- Affichage du texte original alors qu'une traduction est activée.

## Corrections
1. Le `DefaultAudioSink` utilisé pour le lecteur partagé est créé avec les capacités audio par défaut PCM, sans `Context`, afin d'empêcher le passthrough encodé de contourner le processor Sherpa.
2. Le pipeline Sherpa reçoit maintenant des blocs audio horodatés à leur instant de capture. Les timestamps Sherpa sont convertis vers cette horloge plutôt que vers l'heure de fin du décodage.
3. La file audio est limitée à environ 1 seconde et une resynchronisation est demandée lorsqu'une TV ne suit plus le temps réel.
4. Les chargements identiques en parallèle sont bloqués.
5. Un seuil de mémoire beaucoup plus conservateur empêche le chargement natif si la TV n'a pas assez de RAM libre.
6. Le modèle arabe/multilingue est désactivé une fois par migration sur les TV/terminaux faible RAM afin d'éviter sa réactivation automatique après mise à jour. Il reste activable manuellement, mais le garde-fou mémoire peut refuser son chargement.
7. Le modèle français passe au modèle streaming Kroko 2025 (~71 Mo) au lieu de l'ancien modèle français 2023 (~128 Mo).
8. Lorsque la traduction est activée, le texte source est explicitement masqué. Il n'est plus utilisé comme fallback pendant que la traduction est en cours.
9. Les traductions vocales périmées sont rejetées par un numéro de génération : une traduction d'une ancienne phrase ne peut plus remplacer la traduction de la phrase courante.
10. Lorsque le sous-titrage vocal est désactivé, le modèle ONNX est libéré pour récupérer la RAM et les buffers natifs.

## Vérification
Le projet fourni ne contient pas `gradlew` et l'environnement de travail ne dispose pas de Gradle/Android SDK complet ; un `assembleDebug` complet n'a donc pas pu être exécuté ici.
