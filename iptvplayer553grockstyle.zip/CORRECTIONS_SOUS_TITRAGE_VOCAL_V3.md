# V3 – correctifs Android TV

- Le rapport fourni montre que le bouton « Générer Rapport de Crash » créait volontairement une RuntimeException synthétique. Le bouton est maintenant non fatal et produit un rapport clairement marqué TEST NON FATAL.
- Le mode Auto ne déduit plus l’arabe à partir de TUNIS/MBC/BEIN/MAROC/etc. L’arabe n’est sélectionné automatiquement qu’en présence d’écriture arabe ou d’un marqueur AR explicite.
- L’action d’application globale des réglages ne relance plus le moteur Sherpa et ne recharge plus silencieusement un modèle vocal. Les changements de langue vocale restent explicites.
- Le garde-fou mémoire Android TV a été ajusté pour permettre le modèle français/anglais int8 lorsque la TV dispose d’environ 400–500 Mo libres, tout en conservant un seuil de 1200 Mo pour le modèle arabe lourd.
- La logique de traduction déjà présente continue d’afficher uniquement la traduction lorsque la traduction est activée.

---
# V4 – Confort de lecture + rapport de crash instantané

## Sous-titres plus lisibles sur Google TV
- Tailles augmentées pour visionnage à distance :
  - Petit 22 sp · Moyen 30 sp · Grand 40 sp · Très Grand 52 sp · **Énorme 64 sp** (nouveau)
- Durée d’affichage intelligente allongée : 2,2 s + 80 ms/caractère (3,5–14 s) au lieu de 1,5 s + 60 ms (2,5–8 s).
- Overlay : fond plus opaque, ombre plus marquée, marges et padding agrandis, max 4 lignes, largeur max 92 %.

## Rapport de crash instantané
- Écriture synchrone + fsync dans `crash_last.txt` et `last_crash_debug_log.txt` (survivit au kill).
- Rapport enrichi : RAM JVM, RAM système libre, ABI, stacktrace complète.
- Au prochain lancement : **dialogue automatique** avec le rapport + boutons Copier / Télécharger / Fermer (plus seulement un Toast).
- Flag `show_crash_dialog` pour ne l’afficher qu’une fois.

---
# V5 – Confort lecture + stabilité Google TV faible

## Confort de lecture des sous-titres vocaux
- Taille par défaut : **Grand (40 sp)** au lieu de Moyen.
- Tailles : Petit 22 · Moyen 30 · Grand 40 · Très Grand 52 · Énorme 64.
- Durée d’affichage : 2,8 s + 90 ms/caractère (4–16 s) — temps suffisant à 2–3 m.
- Délai manuel par défaut : 8 s.
- Overlay : fond plus opaque (α≥0,82), ombre renforcée, max 5 lignes, largeur 94 %, interligne 1,45.

## Stabilité CPU (TV configuration réduite)
- Décodage adaptatif :
  - silence → 2 étapes
  - RTF ≥ 1,15 → 5 étapes
  - RTF ≥ 0,85 → 10 étapes
  - TV / low-RAM → max 16 étapes
  - sinon → 28
- Objectif : le modèle FR reste en temps réel, moins de mots perdus, UI fluide.
