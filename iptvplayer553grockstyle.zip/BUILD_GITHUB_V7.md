# Pro IPTV - GitHub build V7

Cette archive est conçue pour être utilisée avec le workflow GitHub qui décompresse `iptvplayer541.zip`.

## Utilisation

1. Mettre `iptvplayer541.zip` à la racine du dépôt.
2. Mettre `.github/workflows/build-apk.yml` avec le workflow de compilation habituel.
3. Dans le workflow, conserver uniquement le nom `iptvplayer541.zip`.
4. Le fichier `app/build.gradle.kts` télécharge automatiquement l'AAR officiel Sherpa-ONNX 1.10.42 et vérifie son SHA-256 avant la compilation.

Il n'y a pas de faux AAR ni de stub Sherpa dans cette version.
