package com.example.data

import android.app.ActivityManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import com.example.debug.GlobalDebugSystem
import com.k2fsa.sherpa.onnx.EndpointConfig
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OnlineModelConfig
import com.k2fsa.sherpa.onnx.OnlineRecognizer
import com.k2fsa.sherpa.onnx.OnlineRecognizerConfig
import com.k2fsa.sherpa.onnx.OnlineStream
import com.k2fsa.sherpa.onnx.OnlineTransducerModelConfig
import com.k2fsa.sherpa.onnx.getEndpointConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.sqrt

/**
 * Informations sur un modèle vocal Sherpa-ONNX streaming zipformer
 */
data class SherpaModelInfo(
    val id: String,
    val code: String,
    val name: String,
    val size: String,
    val baseUrl: String,
    val dirName: String,
    val fileNames: List<String>
) {
    val displayName: String get() = name
    val sizeDescription: String get() = size
}

typealias VoskModelInfo = SherpaModelInfo

/**
 * Gestionnaire de sous-titrage vocal haute précision et synchronisé basé sur Sherpa-ONNX.
 * Remplace Vosk pour une transcription continue, fluide et parfaitement synchronisée avec la vidéo.
 */
object SherpaSubtitleManager {
    private const val TAG = "SherpaSubtitleMgr"
    private const val SAMPLE_RATE = 16000

    val allModels = mapOf(
        "fr" to "sherpa-onnx-streaming-zipformer-fr-kroko-2025-08-06",
        "en" to "sherpa-onnx-streaming-zipformer-en-20M-2023-02-17",
        "ar" to "sherpa-onnx-streaming-zipformer-ar_en_id_ja_ru_th_vi_zh-2025-02-10",
        "es" to "sherpa-onnx-streaming-zipformer-fr-kroko-2025-08-06",
        "de" to "sherpa-onnx-streaming-zipformer-en-20M-2023-02-17",
        "it" to "sherpa-onnx-streaming-zipformer-fr-kroko-2025-08-06",
        "pt" to "sherpa-onnx-streaming-zipformer-fr-kroko-2025-08-06",
        "tr" to "sherpa-onnx-streaming-zipformer-en-20M-2023-02-17",
        "ru" to "sherpa-onnx-streaming-zipformer-ar_en_id_ja_ru_th_vi_zh-2025-02-10"
    )

    val AVAILABLE_MODELS = listOf(
        SherpaModelInfo(
            id = "fr",
            code = "fr",
            name = "Français (Kroko 2025, streaming)",
            size = "~71 Mo",
            baseUrl = "https://huggingface.co/csukuangfj/sherpa-onnx-streaming-zipformer-fr-kroko-2025-08-06/resolve/main/",
            dirName = "sherpa-onnx-streaming-zipformer-fr-kroko-2025-08-06",
            fileNames = listOf(
                "tokens.txt",
                "encoder.onnx",
                "decoder.onnx",
                "joiner.onnx"
            )
        ),
        SherpaModelInfo(
            id = "en",
            code = "en",
            name = "Anglais (Zipformer EN 20M)",
            size = "~44 Mo",
            baseUrl = "https://huggingface.co/csukuangfj/sherpa-onnx-streaming-zipformer-en-20M-2023-02-17/resolve/main/",
            dirName = "sherpa-onnx-streaming-zipformer-en-20M-2023-02-17",
            fileNames = listOf(
                "tokens.txt",
                "encoder-epoch-99-avg-1.int8.onnx",
                "decoder-epoch-99-avg-1.int8.onnx",
                "joiner-epoch-99-avg-1.int8.onnx"
            )
        ),
        SherpaModelInfo(
            id = "ar",
            code = "ar",
            name = "Arabe & Multilingue (Zipformer)",
            size = "~339 Mo",
            baseUrl = "https://huggingface.co/csukuangfj/sherpa-onnx-streaming-zipformer-ar_en_id_ja_ru_th_vi_zh-2025-02-10/resolve/main/",
            dirName = "sherpa-onnx-streaming-zipformer-ar_en_id_ja_ru_th_vi_zh-2025-02-10",
            fileNames = listOf(
                "tokens.txt",
                "bpe.model",
                "encoder-epoch-75-avg-11-chunk-16-left-128.int8.onnx",
                "decoder-epoch-75-avg-11-chunk-16-left-128.onnx",
                "joiner-epoch-75-avg-11-chunk-16-left-128.int8.onnx"
            )
        )
    )

    // États observables pour l'UI
    private val _isDownloadingModel = MutableStateFlow(false)
    val isDownloadingModel: StateFlow<Boolean> = _isDownloadingModel.asStateFlow()

    private val _downloadProgress = MutableStateFlow(0f)
    val downloadProgress: StateFlow<Float> = _downloadProgress.asStateFlow()

    private val _downloadStatusMessage = MutableStateFlow<String?>(null)
    val downloadStatusMessage: StateFlow<String?> = _downloadStatusMessage.asStateFlow()

    private val _selectedVoiceModelId = MutableStateFlow("fr")
    val selectedVoiceModelId: StateFlow<String> = _selectedVoiceModelId.asStateFlow()

    private val _isVoiceRecognitionActive = MutableStateFlow(false)
    val isVoiceRecognitionActive: StateFlow<Boolean> = _isVoiceRecognitionActive.asStateFlow()

    private val _recognizedSpeechText = MutableStateFlow<String?>(null)
    val recognizedSpeechText: StateFlow<String?> = _recognizedSpeechText.asStateFlow()

    private val _isSpeechDetected = MutableStateFlow(false)
    val isSpeechDetected: StateFlow<Boolean> = _isSpeechDetected.asStateFlow()

    private val _syncOffsetMs = MutableStateFlow(0)
    val syncOffsetMs: StateFlow<Int> = _syncOffsetMs.asStateFlow()

    private val _isAutoCalibrationEnabled = MutableStateFlow(true)
    val isAutoCalibrationEnabled: StateFlow<Boolean> = _isAutoCalibrationEnabled.asStateFlow()

    private val _autoCalibratedOffsetMs = MutableStateFlow(0)
    val autoCalibratedOffsetMs: StateFlow<Int> = _autoCalibratedOffsetMs.asStateFlow()

    private val _autoClearDelaySeconds = MutableStateFlow(6)
    val autoClearDelaySeconds: StateFlow<Int> = _autoClearDelaySeconds.asStateFlow()

    private val _isIntelligentDurationEnabled = MutableStateFlow(true)
    val isIntelligentDurationEnabled: StateFlow<Boolean> = _isIntelligentDurationEnabled.asStateFlow()

    private val _isStreamingMode = MutableStateFlow(true)
    val isStreamingMode: StateFlow<Boolean> = _isStreamingMode.asStateFlow()

    // Gestion interne du moteur Sherpa-ONNX
    private var currentRecognizer: OnlineRecognizer? = null
    private var currentStream: OnlineStream? = null
    private var currentLoadedLanguage: String? = null
    private val recognizerLock = Any()
    private val downloadMutex = Mutex()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // Dispatcher dédié en arrière-plan optimisé pour Google TV & Smartphone (priorité normale pour ne pas être bridé par le kernel TV)
    private val recognitionDispatcher = java.util.concurrent.Executors.newSingleThreadExecutor { runnable ->
        Thread({
            // Priorité élevée : sur TV, le décodage vidéo/UI écrasait ce thread (modèle plus lent que le temps réel)
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY) } catch (t: Throwable) { }
            runnable.run()
        }, "SherpaWorkerThread").apply {
            priority = Thread.NORM_PRIORITY
        }
    }.asCoroutineDispatcher()

    // Canal audio séquentiel non bloquant (capacité 64 pour absorber les pics CPU sur TV sans perte)
    private data class AudioChunk(
        val samples: FloatArray,
        val captureElapsedMs: Long,
        val durationMs: Long
    )

    // 1 seconde max. Une file plus longue transforme une TV lente en retard de plusieurs secondes.
    private val audioProcessingChannel = Channel<AudioChunk>(
        capacity = 10,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    private var workerJob: Job? = null
    private var loadModelJob: Job? = null
    private var activeDownloadJob: Job? = null
    private var activeDownloadModelId: String? = null
    private val isResetRequested = AtomicBoolean(false)

    // Accumulateur d'échantillons float (100ms = 1600 float samples @ 16kHz)
    private val sampleAccumulator = FloatArray(6400)
    private var sampleAccumulatorSize = 0
    private val sampleLock = Any()
    @Volatile private var lastAudioFeedTime = 0L
    @Volatile private var lastPartialText = ""

    // Horloge de synchronisation de la parole : les timestamps Sherpa sont relatifs
    // au flux audio accepté par le recognizer. On les convertit en temps monotone
    // afin d'afficher le sous-titre au moment où la parole a réellement eu lieu,
    // et non au moment où le CPU termine le décodage.
    @Volatile private var speechSegmentStartElapsedMs = 0L
    // Petite marge seulement : le timestamp est maintenant ancré sur l'instant de capture
    // du bloc audio, et non sur l'instant où le CPU termine le décodage.
    private const val TV_AUDIO_PIPELINE_LATENCY_MS = 40L
    private const val PARTIAL_DISPLAY_DELAY_MS = 50L

    // Jobs de temporisation pour l'affichage
    private var autoClearJob: Job? = null
    private var delayedEmitJob: Job? = null

    // Callbacks demandés par l'utilisateur
    private var onPartialListener: ((text: String) -> Unit)? = null
    private var onFinalListener: ((text: String, startTime: Float, endTime: Float) -> Unit)? = null
    private var onSpeechResultListener: ((rawText: String) -> Unit)? = null

    @Volatile private var appContext: Context? = null

    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(300, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    @Volatile private var isRecognizerReady = false
    @Volatile private var isStreamReady = false

    // Les callbacks UI sont postés sur le thread principal SANS bloquer le worker audio
    // (l'ancien withContext(Main) faisait attendre le décodage quand l'UI TV était chargée -> perte d'audio).
    private val mainHandler = Handler(Looper.getMainLooper())

    // Ligne à retard : chaque résultat est numéroté, les résultats périmés (reset/seek) sont ignorés
    private val emitSequence = AtomicLong(0)
    private val emitLock = Any()
    private var lastEmittedSequence = 0L
    @Volatile var lastEmittedIsFinal: Boolean = false
        private set

    // Gain adaptatif lissé (évite le "pompage" du gain d'un chunk à l'autre)
    private var agcGain = 1.0f

    private val standaloneEnglishI = Regex("\\bi\\b")

    // ---- Diagnostic affiché à l'écran (utile sur TV où il n'y a pas de logcat) ----
    @Volatile private var diagFormat = "format audio inconnu"
    @Volatile private var diagInputCalls = 0L
    @Volatile private var diagChunksQueued = 0L
    @Volatile private var diagChunksDecoded = 0L
    @Volatile private var diagLastRms = 0f
    private val _diagnostics = MutableStateFlow("")
    val diagnostics: StateFlow<String> = _diagnostics.asStateFlow()

    // ---- Chargement du modèle : file unique (jamais deux chargements en parallèle) ----
    private val loadMutex = Mutex()
    @Volatile private var requestedModelId: String? = null
    @Volatile private var loadingSinceMs = 0L
    @Volatile private var lastLoadError: String? = null
    @Volatile private var loadFailures = 0
    @Volatile private var diagDropped = 0L
    @Volatile private var needResync = false
    @Volatile private var rtf = 0f            // temps de calcul / durée d'audio (>1 = trop lent)
    private var rtfDecodeMs = 0.0
    private var rtfAudioMs = 0.0

    // Watchdog du flux Sherpa : un OnlineStream peut devenir invalide après une
    // exception JNI ou après un changement de chaîne. On recrée uniquement le stream
    // (pas le modèle ONNX) afin de récupérer la reconnaissance sans recharger ~130 Mo.
    @Volatile private var lastSherpaProgressMs = 0L
    private val streamRecoveryRunning = AtomicBoolean(false)
    @Volatile private var streamRecoveryCount = 0

    @Volatile private var modelMismatch = false

    // ---- Interrupteur "modèle arabe / multilingue" (le plus lourd : ~340 Mo, plantages sur TV 2 Go) ----
    private val _arabicModelEnabled = MutableStateFlow(false)
    val arabicModelEnabled: StateFlow<Boolean> = _arabicModelEnabled.asStateFlow()

    private fun heavyModelPrefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("sherpa_options", Context.MODE_PRIVATE)

    /** Par défaut : désactivé sur une TV (ou un appareil <= 3 Go de RAM), activé sur smartphone/tablette. */
    private fun loadHeavyModelOption(ctx: Context) {
        try {
            val prefs = heavyModelPrefs(ctx)
            val ui = ctx.getSystemService(Context.UI_MODE_SERVICE) as? android.app.UiModeManager
            val isTv = ui?.currentModeType == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
            val lowRam = mi.totalMem <= 3L * 1024 * 1024 * 1024

            // Migration de sécurité pour les TV : les anciennes versions pouvaient laisser
            // le modèle arabe lourd activé. On le coupe UNE FOIS après la mise à jour, puis
            // le choix manuel de l'utilisateur est conservé.
            val migrated = prefs.getBoolean("arabic_tv_safe_mode_v2", false)
            if ((isTv || lowRam) && !migrated) {
                _arabicModelEnabled.value = false
                prefs.edit()
                    .putBoolean("arabic_model_enabled", false)
                    .putBoolean("arabic_tv_safe_mode_v2", true)
                    .apply()
            } else if (prefs.contains("arabic_model_enabled")) {
                _arabicModelEnabled.value = prefs.getBoolean("arabic_model_enabled", false)
            } else {
                _arabicModelEnabled.value = !(isTv || lowRam)
            }
        } catch (t: Throwable) { }
    }

    private fun isHeavyModelDisabled(modelId: String) = modelId == "ar" && !_arabicModelEnabled.value

    /** Libère immédiatement le modèle chargé (RAM + CPU). */
    fun unloadModel() {
        synchronized(recognizerLock) {
            isRecognizerReady = false
            isStreamReady = false
            try { currentStream?.release() } catch (t: Throwable) { }
            try { currentRecognizer?.release() } catch (t: Throwable) { }
            currentStream = null
            currentRecognizer = null
            currentLoadedLanguage = null
        }
        System.gc()
    }

    /** Active/désactive le modèle arabe & multilingue. Désactivé : jamais chargé, jamais décodé, mémoire libérée. */
    fun setArabicModelEnabled(context: Context, enabled: Boolean) {
        _arabicModelEnabled.value = enabled
        try { heavyModelPrefs(context).edit().putBoolean("arabic_model_enabled", enabled).apply() } catch (t: Throwable) { }
        if (!enabled) {
            if (synchronized(recognizerLock) { currentLoadedLanguage == "ar" }) unloadModel()
            lastLoadError = null
            loadFailures = 0
            if (expectedModelId() == "ar") {
                _downloadStatusMessage.value = "Modèle arabe/multilingue désactivé (économie de mémoire et de CPU)."
                resetRecognitionState()
            }
        } else if (_isVoiceRecognitionActive.value && expectedModelId() == "ar") {
            setSourceLanguage("ar", context)
        }
    }
    @Volatile private var nativeLibError: String? = null

    // ---- Décodage : glouton (rapide) par défaut ; faisceau (4x plus lourd) seulement sur appareil puissant ----
    @Volatile private var forceGreedy = false
    @Volatile private var slowLatched = false
    @Volatile private var slowSinceMs = 0L

    private fun isTvOrLowRam(ctx: Context?): Boolean {
        if (ctx == null) return true
        return try {
            val ui = ctx.getSystemService(Context.UI_MODE_SERVICE) as? android.app.UiModeManager
            val isTv = ui?.currentModeType == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
            isTv || mi.totalMem <= 4L * 1024 * 1024 * 1024
        } catch (t: Throwable) { true }
    }

    private fun shouldUseBeamSearch(languageCode: String, cores: Int): Boolean {
        if (forceGreedy || languageCode == "ar") return false
        // Le beam search n'apporte pas assez sur un flux TV pour justifier son coût CPU.
        // Il reste réservé aux smartphones/tablettes réellement puissants.
        if (isTvOrLowRam(appContext)) return false
        if (cores < 6) return false
        return true
    }

    /**
     * Recrée le flux de décodage sans recharger le modèle ONNX.
     * Cette récupération est volontairement légère pour les TV 2 Go : un seul
     * OnlineRecognizer reste en mémoire et seul son OnlineStream est remplacé.
     */
    private fun recoverStream(reason: String) {
        if (!_isVoiceRecognitionActive.value) return
        if (!streamRecoveryRunning.compareAndSet(false, true)) return
        try {
            synchronized(recognizerLock) {
                val recognizer = currentRecognizer
                if (recognizer == null || !isRecognizerReady) return@synchronized
                val oldStream = currentStream
                isStreamReady = false
                try { oldStream?.release() } catch (_: Throwable) { }
                currentStream = null
                try {
                    val newStream = recognizer.createStream()
                    currentStream = newStream
                    isStreamReady = true
                    lastSherpaProgressMs = SystemClock.elapsedRealtime()
                    streamRecoveryCount++
                    speechSegmentStartElapsedMs = 0L
                    lastPartialText = ""
                    Log.w(TAG, "Sherpa stream recréé ($reason), récupération #$streamRecoveryCount")
                } catch (t: Throwable) {
                    currentStream = null
                    isStreamReady = false
                    Log.e(TAG, "Impossible de recréer le stream Sherpa: ${t.message}")
                }
            }
        } finally {
            streamRecoveryRunning.set(false)
        }
    }

    /** Si le calcul est > 1x le temps réel pendant 12 s : bascule définitive en décodage glouton et recharge le modèle. */
    private fun adaptiveSpeedGuard() {
        if (rtf <= 0f) { slowSinceMs = 0L; return }
        if (rtf >= 1.0f) {
            if (slowSinceMs == 0L) slowSinceMs = System.currentTimeMillis()
            slowLatched = true
        } else if (rtf < 0.6f) {
            slowSinceMs = 0L
            slowLatched = false
        }
        val slowFor = if (slowSinceMs > 0L) System.currentTimeMillis() - slowSinceMs else 0L
        if (slowFor > 12_000L && !forceGreedy) {
            val ctx = appContext ?: return
            val wasBeam = synchronized(recognizerLock) { currentLoadedLanguage != null && currentLoadedLanguage != "ar" } &&
                shouldUseBeamSearch(currentLoadedLanguage ?: "fr", Runtime.getRuntime().availableProcessors())
            forceGreedy = true
            try { heavyModelPrefs(ctx).edit().putBoolean("force_greedy", true).apply() } catch (t: Throwable) { }
            if (wasBeam) {
                Log.w(TAG, "TV trop lente en décodage par faisceau : bascule en décodage glouton")
                unloadModel()
                rtf = 0f; rtfDecodeMs = 0.0; rtfAudioMs = 0.0; slowSinceMs = 0L
            }
        }
    }

    /** Modèle réellement attendu pour la langue sélectionnée. */
    private fun expectedModelId(): String = getModelInfoForLanguage(_selectedVoiceModelId.value).id

    private fun buildDiagnostics(): String {
        val loadedLang = synchronized(recognizerLock) { if (currentRecognizer != null && isRecognizerReady) currentLoadedLanguage else null }
        val expected = expectedModelId()
        val model = when {
            isHeavyModelDisabled(expected) -> "DÉSACTIVÉ (arabe/multilingue)"
            _isDownloadingModel.value -> "téléchargement…"
            loadedLang != null && loadedLang == expected -> "prêt ($loadedLang)"
            loadedLang != null -> "MAUVAIS modèle (chargé: $loadedLang, attendu: $expected)" + (lastLoadError?.let { " – $it" } ?: "")
            loadingSinceMs > 0L -> "chargement en cours (${(System.currentTimeMillis() - loadingSinceMs) / 1000} s)"
            lastLoadError != null -> "ÉCHEC (${lastLoadError})"
            else -> "NON chargé (en attente)"
        }
        val audio = if (diagInputCalls == 0L) {
            "AUCUN audio PCM reçu du lecteur ($diagFormat)"
        } else {
            "$diagFormat | reçu $diagChunksQueued | décodé $diagChunksDecoded | perdu $diagDropped | niveau ${"%.3f".format(diagLastRms)}"
        }
        val speed = if (rtf > 0f) {
            "\nVitesse calcul: ${"%.2f".format(rtf)}x le temps réel" + if (rtf >= 0.9f) " ⚠ TV trop lente pour ce modèle (mots perdus)" else " (OK)"
        } else ""
        val ram = appContext?.let { c ->
            try {
                val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
                "\nRAM TV: ${mi.availMem / 1048576} Mo libres / ${mi.totalMem / 1048576} Mo"
            } catch (t: Throwable) { "" }
        } ?: ""
        val status = _downloadStatusMessage.value
        val libs = nativeLibError?.let { "\nLib native: $it" } ?: ""
        return "Voix - modèle: $model | $audio" + speed + ram + libs + if (!status.isNullOrBlank()) "\n$status" else ""
    }

    /**
     * Signature COURTE de l'état (sans compteurs ni secondes) : le bandeau de diagnostic ne se réaffiche
     * (quelques secondes) que lorsque cette signature change : modèle prêt, échec, mauvais modèle, TV trop lente...
     */
    private val _diagSignature = MutableStateFlow("")
    val diagSignature: StateFlow<String> = _diagSignature.asStateFlow()

    private fun computeDiagSignature(): String {
        val loadedLang = synchronized(recognizerLock) { if (currentRecognizer != null && isRecognizerReady) currentLoadedLanguage else null }
        val expected = expectedModelId()
        val state = when {
            isHeavyModelDisabled(expected) -> "disabled"
            _isDownloadingModel.value -> "download"
            loadedLang != null && loadedLang == expected -> "ready:$loadedLang"
            loadedLang != null -> "mismatch:$loadedLang>$expected"
            loadingSinceMs > 0L -> "loading"
            lastLoadError != null -> "error:$lastLoadError"
            else -> "waiting"
        }
        return state + if (slowLatched) "|slow" else ""
    }

    /** Vrai s'il y a un problème à montrer en permanence (même quand du texte s'affiche). */
    fun hasDiagnosticProblem(): Boolean = modelMismatch || slowLatched || (lastLoadError != null && loadingSinceMs == 0L)

    /**
     * Si l'audio continue d'arriver mais que Sherpa n'a plus décodé depuis plusieurs
     * secondes, le stream est probablement coincé. On le recrée sans toucher au modèle.
     */
    private fun streamWatchdog() {
        if (!_isVoiceRecognitionActive.value) return
        val now = SystemClock.elapsedRealtime()
        val audioRecent = lastAudioFeedTime > 0L &&
            (System.currentTimeMillis() - lastAudioFeedTime) < 2500L
        val streamReady = synchronized(recognizerLock) {
            currentRecognizer != null && currentStream != null && isRecognizerReady && isStreamReady
        }
        if (!streamReady || !audioRecent) return
        val last = lastSherpaProgressMs
        if (last > 0L && now - last > 5000L) {
            recoverStream("watchdog: aucune progression depuis ${(now - last) / 1000}s")
        }
    }

    /** Relance le chargement si la reconnaissance est active mais qu'aucun modèle n'est chargé ni en cours de chargement. */
    private fun loadWatchdog() {
        if (!_isVoiceRecognitionActive.value) return
        if (_isDownloadingModel.value || loadMutex.isLocked) return
        if (loadFailures >= 3) return
        // Le modèle attendu suit toujours la langue sélectionnée (zapping FR -> AR, etc.)
        val wanted = expectedModelId()
        if (isHeavyModelDisabled(wanted)) return
        requestedModelId = wanted
        val loaded = synchronized(recognizerLock) { currentRecognizer != null && isRecognizerReady && currentLoadedLanguage == wanted }
        if (loaded) return
        val ctx = appContext ?: return
        Log.w(TAG, "Watchdog: modèle non chargé, relance du chargement (${requestedModelId})")
        launchLoader(ctx)
    }

    init {
        // Chaque bibliothèque est chargée séparément : l'échec d'une lib optionnelle
        // (ex. c-api / cxx-api absentes de l'AAR) ne doit plus empêcher le chargement des suivantes.
        for (lib in listOf("onnxruntime", "sherpa-onnx-jni")) {
            try {
                System.loadLibrary(lib)
            } catch (t: Throwable) {
                Log.w(TAG, "Sherpa-ONNX native library '$lib' notice: ${t.message}")
                nativeLibError = "$lib: ${t.message}"
            }
        }
        startAudioWorker()
        scope.launch(Dispatchers.Default) {
            var tick = 0
            while (isActive) {
                delay(1000)
                tick++
                modelMismatch = _isVoiceRecognitionActive.value && synchronized(recognizerLock) {
                    currentRecognizer != null && isRecognizerReady && currentLoadedLanguage != expectedModelId()
                }
                _diagnostics.value = if (_isVoiceRecognitionActive.value) buildDiagnostics() else ""
                _diagSignature.value = if (_isVoiceRecognitionActive.value) computeDiagSignature() else ""
                try { streamWatchdog() } catch (t: Throwable) { Log.w(TAG, "stream watchdog: ${t.message}") }
                try { adaptiveSpeedGuard() } catch (t: Throwable) { }
                if (tick % 4 == 0) {
                    try { loadWatchdog() } catch (t: Throwable) { Log.w(TAG, "watchdog: ${t.message}") }
                }
            }
        }
    }

    fun initialize(context: Context) {
        appContext = context.applicationContext
        resetGuardOnNewInstall(context.applicationContext)
        loadHeavyModelOption(context.applicationContext)
        try { forceGreedy = heavyModelPrefs(context.applicationContext).getBoolean("force_greedy", false) } catch (t: Throwable) { }
    }

    /**
     * Une nouvelle installation (mise à jour de l'app) donne une nouvelle chance aux modèles bloqués
     * après un plantage : le blocage venait peut-être d'une ancienne version (ex. trop de threads).
     * Les modèles téléchargés ne sont PAS supprimés.
     */
    private fun resetGuardOnNewInstall(ctx: Context) {
        try {
            val stamp = ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime
            val prefs = guardPrefs(ctx)
            if (prefs.getLong("install_stamp", -1L) != stamp) {
                val e = prefs.edit()
                for (m in AVAILABLE_MODELS) e.remove("blocked_${m.id}")
                e.remove("loading_model").putLong("install_stamp", stamp).apply()
            }
        } catch (t: Throwable) { }
    }

    // ---- Garde-fou anti boucle de plantage -------------------------------------------------------
    // Un plantage NATIF (manque de mémoire pendant le chargement du modèle de 300 Mo, ou erreur JNI)
    // tue le process sans exception Java. On note donc "chargement en cours" AVANT de charger ; si l'app
    // redémarre avec cette note encore présente, c'est que le chargement précédent a planté : le modèle
    // est alors bloqué au lieu de replanter en boucle à chaque lancement.
    private fun guardPrefs(context: Context) =
        context.applicationContext.getSharedPreferences("sherpa_load_guard", Context.MODE_PRIVATE)

    private fun isModelBlocked(context: Context, modelId: String): Boolean {
        val prefs = guardPrefs(context)
        if (prefs.getString("loading_model", null) == modelId) {
            // Le dernier chargement n'a jamais fini -> crash natif
            prefs.edit().remove("loading_model").putBoolean("blocked_$modelId", true).apply()
        }
        return prefs.getBoolean("blocked_$modelId", false)
    }

    /** Débloque un modèle (à appeler quand l'utilisateur le supprime / le retélécharge explicitement). */
    fun unblockModel(context: Context, modelId: String) {
        guardPrefs(context).edit().remove("blocked_$modelId").remove("loading_model").apply()
    }

    private fun availableMemoryMb(context: Context): Long {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            mi.availMem / (1024 * 1024)
        } catch (t: Throwable) {
            Long.MAX_VALUE
        }
    }

    fun isRecognizerValid(recognizer: OnlineRecognizer?): Boolean {
        return recognizer != null && isRecognizerReady
    }

    fun isStreamValid(stream: OnlineStream?): Boolean {
        return stream != null && isStreamReady
    }

    fun setOnPartialListener(listener: ((text: String) -> Unit)?) {
        onPartialListener = listener
    }

    fun setOnFinalListener(listener: ((text: String, startTime: Float, endTime: Float) -> Unit)?) {
        onFinalListener = listener
    }

    fun setOnSpeechResultListener(listener: ((rawText: String) -> Unit)?) {
        onSpeechResultListener = listener
    }

    fun setSyncOffsetMs(offset: Int) {
        _syncOffsetMs.value = offset.coerceIn(-2000, 5000)
    }

    fun setAutoCalibrationEnabled(enabled: Boolean) {
        _isAutoCalibrationEnabled.value = enabled
    }

    fun setAutoClearDelaySeconds(seconds: Int) {
        _autoClearDelaySeconds.value = seconds.coerceIn(2, 10)
    }

    fun setIntelligentDurationEnabled(enabled: Boolean) {
        _isIntelligentDurationEnabled.value = enabled
    }

    fun setStreamingMode(enabled: Boolean) {
        _isStreamingMode.value = enabled
    }

    fun setSelectedVoiceModelId(modelId: String) {
        val clean = modelId.trim().lowercase()
        val safeId = if (allModels.containsKey(clean) || AVAILABLE_MODELS.any { it.id == clean }) clean else "fr"
        _selectedVoiceModelId.value = safeId
    }

    private fun startAudioWorker() {
        workerJob?.cancel()
        workerJob = scope.launch(recognitionDispatcher) {
            val flushTicker = launch {
                while (isActive) {
                    delay(200)
                    if (System.currentTimeMillis() - lastAudioFeedTime >= 300L) {
                        flushAccumulator()
                    }
                }
            }

            lastPartialText = ""

            for (chunk in audioProcessingChannel) {
                val samples = chunk.samples
                if (pendingChunks.get() > 0) pendingChunks.decrementAndGet()
                diagChunksDecoded++
                if (isResetRequested.getAndSet(false)) {
                    synchronized(recognizerLock) {
                        try {
                            val stream = currentStream
                            val recognizer = currentRecognizer
                            if (isStreamValid(stream) && isRecognizerValid(recognizer)) {
                                recognizer!!.reset(stream!!)
                            }
                        } catch (t: Throwable) { }
                    }
                }

                if (!_isVoiceRecognitionActive.value) continue

                // Jamais de sous-titres issus du MAUVAIS modèle (ex. modèle français qui "lit" de l'arabe en lettres latines)
                if (modelMismatch) continue

                // Des blocs audio ont été perdus (TV trop lente) : on repart d'un état propre plutôt que de
                // décoder un flux troué qui produit des mots absurdes.
                if (needResync) {
                    needResync = false
                    speechSegmentStartElapsedMs = chunk.captureElapsedMs
                    synchronized(recognizerLock) {
                        try {
                            val st = currentStream
                            val rc = currentRecognizer
                            if (isStreamValid(st) && isRecognizerValid(rc)) rc!!.reset(st!!)
                        } catch (t: Throwable) { }
                    }
                }

                // Conditionnement acoustique léger et lissé
                applyAcousticNormalization(samples, samples.size)

                var finalResult: String? = null
                var partialResult: String? = null
                var startTime = 0f
                var endTime = 0f
                val decodeStartTime = System.currentTimeMillis()
                val audioMs = samples.size * 1000f / SAMPLE_RATE
                if (speechSegmentStartElapsedMs == 0L) {
                    // Ancrage sur le temps de CAPTURE, pas sur le temps de décodage.
                    // Cela supprime le retard variable de la file CPU sur les TV lentes.
                    speechSegmentStartElapsedMs = chunk.captureElapsedMs
                }

                // Google TV faible : plafond de décodage adaptatif pour ne pas saturer le SoC
                // et laisser le temps au thread vidéo. Silence → quasi-skip.
                val currentRms = diagLastRms
                val isLikelySilence = currentRms < 0.0025f && lastPartialText.isBlank()
                val maxDecodeSteps = when {
                    isLikelySilence -> 2
                    rtf >= 1.15f -> 5
                    rtf >= 0.85f -> 10
                    isTvOrLowRam(appContext) -> 16
                    else -> 28
                }

                synchronized(recognizerLock) {
                    val recognizer = currentRecognizer ?: return@synchronized
                    val stream = currentStream ?: return@synchronized
                    if (!isRecognizerValid(recognizer) || !isStreamValid(stream)) {
                        return@synchronized
                    }
                    try {
                        stream.acceptWaveform(samples, SAMPLE_RATE)
                        var decodeSteps = 0
                        // Décodage plafonné et adaptatif pour ne jamais monopoliser le CPU d'un boîtier Google TV
                        while (isRecognizerValid(recognizer) && isStreamValid(stream) && recognizer.isReady(stream) && decodeSteps < maxDecodeSteps && !isResetRequested.get()) {
                            recognizer.decode(stream)
                            decodeSteps++
                            lastSherpaProgressMs = SystemClock.elapsedRealtime()
                        }
                        if (isRecognizerValid(recognizer) && isStreamValid(stream)) {
                            val isEndpointDetected = recognizer.isEndpoint(stream)
                            val res = recognizer.getResult(stream)
                            val clean = cleanRecognizedSpeech(res.text)

                            if (isEndpointDetected) {
                                if (clean.isNotBlank()) {
                                    finalResult = clean
                                    try {
                                        val timestamps = res.timestamps
                                        if (timestamps.isNotEmpty()) {
                                            startTime = timestamps.first()
                                            endTime = timestamps.last()
                                        }
                                    } catch (t: Throwable) { }
                                }
                                if (isRecognizerValid(recognizer) && isStreamValid(stream)) {
                                    recognizer.reset(stream)
                                }
                            } else if (clean.isNotBlank() && clean != lastPartialText) {
                                // CORRECTIF : on ne met PAS à jour lastPartialText ici.
                                // Avant, la valeur était écrasée avant le test de nouveauté plus bas
                                // et les sous-titres partiels (temps réel) n'étaient jamais émis.
                                partialResult = clean
                            }
                        }
                    } catch (t: Throwable) {
                        Log.w(TAG, "Erreur décodage Sherpa-ONNX: ${t.message}")
                        // Une exception Java/JNI ne doit pas laisser le stream dans un état
                        // mort jusqu'au prochain changement de chaîne. Le modèle reste chargé.
                        recoverStream("exception décodage")
                    }
                }

                // Calibrage automatique : latence de décodage mesurée (sans délai artificiel de base)
                val decodeElapsed = (System.currentTimeMillis() - decodeStartTime)
                if (audioMs > 0f) {
                    // Rapport de sommes (fenêtre glissante) : insensible à la taille variable des blocs
                    rtfDecodeMs = rtfDecodeMs * 0.995 + decodeElapsed
                    rtfAudioMs = rtfAudioMs * 0.995 + audioMs
                    if (rtfAudioMs > 3000.0) rtf = (rtfDecodeMs / rtfAudioMs).toFloat()
                }
                if (finalResult != null || partialResult != null) {
                    val measuredLag = decodeElapsed.toInt().coerceIn(0, 400)
                    _autoCalibratedOffsetMs.value = (0.85f * _autoCalibratedOffsetMs.value + 0.15f * measuredLag).toInt()
                }

                val safeFinal = finalResult
                val safePartial = partialResult
                if (safeFinal != null && safeFinal.isNotBlank()) {
                    lastPartialText = ""
                    val shown = formatForDisplay(safeFinal, 140)
                    val st = startTime
                    val et = endTime
                    GlobalDebugSystem.logFunctionCall(
                        "Sherpa_OnFinal",
                        "text" to shown,
                        "startTime" to st,
                        "endTime" to et
                    )
                    mainHandler.post {
                        try {
                            onFinalListener?.invoke(shown, st, et)
                        } catch (t: Throwable) {
                            Log.e(TAG, "Erreur onFinalListener: ${t.message}")
                        }
                    }
                    val target = if (st > 0f || et > 0f) {
                        speechSegmentStartElapsedMs + (et * 1000f).toLong() + TV_AUDIO_PIPELINE_LATENCY_MS
                    } else {
                        0L
                    }
                    dispatchSpeechResult(shown, isFinal = true, targetElapsedMs = target)
                    // Endpoint => le prochain bloc audio donnera le nouvel ancrage de capture.
                    speechSegmentStartElapsedMs = 0L
                } else if (safePartial != null && safePartial.isNotBlank()) {
                    lastPartialText = safePartial
                    val shown = formatForDisplay(safePartial, 90)
                    mainHandler.post {
                        try {
                            onPartialListener?.invoke(shown)
                        } catch (t: Throwable) {
                            Log.e(TAG, "Erreur onPartialListener: ${t.message}")
                        }
                    }
                    if (_isStreamingMode.value) {
                        dispatchSpeechResult(
                            shown,
                            isFinal = false,
                            targetElapsedMs = maxOf(
                                SystemClock.elapsedRealtime(),
                                chunk.captureElapsedMs + chunk.durationMs + PARTIAL_DISPLAY_DELAY_MS
                            )
                        )
                    }
                }
            }
            flushTicker.cancel()
        }
    }

    /**
     * Mise en forme pour l'affichage TV (grandes polices) :
     * - MAJUSCULES des modèles EN → casse normale ;
     * - majuscule en début de phrase et après . ! ? ;
     * - fenêtre glissante (~2–3 lignes) pour ne jamais noyer l'écran.
     */
    private fun formatForDisplay(raw: String, maxChars: Int): String {
        var s = raw.trim()
        if (s.isEmpty()) return s
        val letters = s.count { it.isLetter() }
        if (letters >= 4) {
            val upper = s.count { it.isUpperCase() }
            if (upper.toFloat() / letters.toFloat() > 0.65f) {
                s = s.lowercase()
            }
        }
        if (currentLoadedLanguage == "en") {
            s = s.replace(standaloneEnglishI, "I")
        }
        s = s.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        s = s.replace(Regex("([.!?…]\\s+)([a-zàâäéèêëïîôùûüç])")) { m ->
            m.groupValues[1] + m.groupValues[2].uppercase()
        }
        if (s.length > maxChars) {
            val cut = s.length - maxChars
            val space = s.indexOf(' ', cut)
            s = if (space in 0 until (s.length - 1)) s.substring(space + 1) else s.substring(cut)
        }
        return s
    }

    private fun notifySpeechResult(text: String) {
        mainHandler.post {
            try {
                onSpeechResultListener?.invoke(text)
            } catch (t: Throwable) {
                Log.e(TAG, "Erreur onSpeechResultListener: ${t.message}")
            }
        }
    }

    private val pendingChunks = java.util.concurrent.atomic.AtomicInteger(0)
    // 1 seconde maximum d'audio en attente : au-delà, il vaut mieux resynchroniser
    // que laisser les sous-titres dériver de plusieurs secondes derrière la vidéo.
    private val CHUNK_CAPACITY = 10
    @Volatile private var lastResyncMs = 0L

    private fun enqueueChunk(chunk: FloatArray) {
        lastAudioFeedTime = System.currentTimeMillis()
        diagChunksQueued++
        // Le canal est en DROP_OLDEST : trySend ne « échoue » jamais, il jette silencieusement le plus ancien.
        // On compte donc nous-mêmes les blocs en attente pour savoir quand de l'audio est réellement perdu.
        if (pendingChunks.incrementAndGet() > CHUNK_CAPACITY) {
            pendingChunks.decrementAndGet()
            diagDropped++
            val now = System.currentTimeMillis()
            // Remise à zéro du flux au plus 1 fois / 4 s (sinon aucune phrase n'aboutit quand la TV est trop lente)
            if (now - lastResyncMs > 4000L) { needResync = true; lastResyncMs = now }
        }
        val now = SystemClock.elapsedRealtime()
        val durationMs = (chunk.size * 1000L / SAMPLE_RATE).coerceAtLeast(1L)
        audioProcessingChannel.trySend(AudioChunk(chunk, now - durationMs, durationMs))
    }

    /**
     * Sélectionne et recharge le modèle de la langue source Sherpa-ONNX.
     * Télécharge automatiquement le modèle depuis HuggingFace s'il n'est pas encore installé.
     */
    fun setSourceLanguage(code: String, customContext: Context? = null) {
        val cleanCode = code.trim().lowercase()
        val requestedId = if (allModels.containsKey(cleanCode) || AVAILABLE_MODELS.any { it.id == cleanCode }) cleanCode else "fr"
        setSelectedVoiceModelId(requestedId)

        // On travaille désormais avec le modèle RÉEL (ex. "ru" -> modèle multilingue),
        // ce qui évite aussi de recharger inutilement le même modèle sous un autre code.
        val modelInfo = getModelInfoForLanguage(requestedId)
        val safeId = modelInfo.id
        if (AVAILABLE_MODELS.none { it.id == requestedId }) {
            _downloadStatusMessage.value = "Pas de modèle vocal hors-ligne dédié pour « $requestedId » : le modèle ${modelInfo.name} est utilisé (transcription approximative)."
        }

        val context = customContext ?: appContext
        if (context == null) {
            Log.w(TAG, "Context non disponible pour setSourceLanguage($safeId)")
            return
        }

        // Si le même modèle est déjà en cours de téléchargement/chargement, ne pas lancer
        // une deuxième opération native. C'était une cause de montée RAM et de crash sur TV.
        if (requestedModelId == safeId && (loadModelJob?.isActive == true || loadMutex.isLocked)) {
            _isVoiceRecognitionActive.value = true
            return
        }

        if (isHeavyModelDisabled(safeId)) {
            // Modèle lourd désactivé par l'utilisateur : on libère tout et on ne charge rien.
            requestedModelId = null
            if (synchronized(recognizerLock) { currentLoadedLanguage != null }) unloadModel()
            _downloadStatusMessage.value = "Modèle arabe/multilingue désactivé (Réglages > Sous-titres vocaux)."
            _isVoiceRecognitionActive.value = true
            resetRecognitionState()
            return
        }

        synchronized(recognizerLock) {
            if (currentLoadedLanguage == safeId && currentRecognizer != null && currentStream != null) {
                _isVoiceRecognitionActive.value = true
                resetRecognitionState()
                return
            }
        }

        // Demande explicite : on mémorise le modèle voulu et on (re)lance le chargeur.
        // Le chargeur est sérialisé (loadMutex) : plus aucun chargement parallèle, plus d'annulation
        // d'un chargement natif en cours (qui ne peut pas être interrompu et saturait la RAM de la TV).
        requestedModelId = safeId
        loadFailures = 0
        launchLoader(context)
    }

    private fun launchLoader(context: Context) {
        loadModelJob = scope.launch(Dispatchers.IO) {
            loadMutex.withLock {
                var iterations = 0
                while (iterations++ < 4) {
                    val targetId = requestedModelId ?: break
                    if (isHeavyModelDisabled(targetId)) break
                    val info = AVAILABLE_MODELS.firstOrNull { it.id == targetId } ?: break
                    val already = synchronized(recognizerLock) {
                        currentLoadedLanguage == targetId && currentRecognizer != null && currentStream != null && isRecognizerReady
                    }
                    if (already) break
                    val ok = try {
                        loadModelBlocking(context, info)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (t: Throwable) {
                        Log.e(TAG, "Erreur chargement Sherpa modèle $targetId: ${t.message}", t)
                        lastLoadError = t.message ?: t.javaClass.simpleName
                        _downloadStatusMessage.value = "Erreur chargement Sherpa: ${lastLoadError}"
                        false
                    }
                    if (!ok) {
                        loadFailures++
                        break
                    }
                    loadFailures = 0
                }
            }
        }
    }

    /** Télécharge si besoin puis charge le modèle. Appelé uniquement sous loadMutex. */
    private suspend fun loadModelBlocking(context: Context, modelInfo: SherpaModelInfo): Boolean {
        loadingSinceMs = System.currentTimeMillis()
        lastLoadError = null
        try {
            val safeId = modelInfo.id
            val modelDir = getModelDirectory(context, modelInfo)

            if (!isModelInstalled(context, modelInfo)) {
                _downloadStatusMessage.value = "Téléchargement modèle Sherpa ${modelInfo.name}..."
                val downloaded = downloadAndExtractModel(context, modelInfo)
                if (!downloaded || !isModelInstalled(context, modelInfo)) {
                    lastLoadError = "téléchargement incomplet"
                    _downloadStatusMessage.value = "Échec du téléchargement pour ${modelInfo.name}"
                    return false
                }
            }

            if (isModelBlocked(context, safeId)) {
                lastLoadError = "modèle bloqué après un plantage"
                _downloadStatusMessage.value = "Le chargement de « ${modelInfo.name} » a fait planter l'application (mémoire insuffisante probable sur cette TV). Modèle désactivé : choisis un modèle plus léger (Français / Anglais)."
                return false
            }

            // Estimation de la mémoire nécessaire : ~1,5 x la taille des fichiers du modèle.
            // Simple avertissement (availMem sous-estime souvent la mémoire réellement récupérable) ;
            // le garde-fou anti-plantage protège en cas de vrai manque de mémoire.
            // Libérer l'ancien modèle AVANT de mesurer la mémoire libre (sinon FR + AR comptent ensemble)
            synchronized(recognizerLock) {
                if (currentLoadedLanguage != null && currentLoadedLanguage != safeId) {
                    isRecognizerReady = false
                    isStreamReady = false
                    try { currentStream?.release() } catch (t: Throwable) { }
                    try { currentRecognizer?.release() } catch (t: Throwable) { }
                    currentStream = null
                    currentRecognizer = null
                    currentLoadedLanguage = null
                }
            }
            System.gc()
            val modelBytes = modelInfo.fileNames.sumOf { File(modelDir, it).length() }
            val modelMb = ((modelBytes + 1048575L) / 1048576L).coerceAtLeast(1L)
            val tv = isTvOrLowRam(context)
            val minSafeFreeMb = when {
                // Le modèle arabe/multilingue est volontairement très conservateur sur TV 2 Go.
                safeId == "ar" -> 1200L
                // Le modèle FR Kroko fait ~130 Mo sur disque mais son empreinte native reste
                // nettement inférieure à 5x la taille du fichier. L'ancien seuil (modelMb * 5)
                // refusait inutilement le chargement avec ~600 Mo libres, alors que le modèle
                // fonctionnait déjà sur cette TV. Garder une marge fixe de 500 Mo évite le refus
                // prématuré tout en protégeant les appareils vraiment à court de RAM.
                tv -> maxOf(500L, modelMb * 3L)
                else -> maxOf(450L, modelMb * 3L)
            }
            val freeMb = availableMemoryMb(context)
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val memoryInfo = ActivityManager.MemoryInfo()
            val lowMemory = try {
                am?.getMemoryInfo(memoryInfo)
                memoryInfo.lowMemory
            } catch (_: Throwable) { false }
            if (lowMemory || freeMb < minSafeFreeMb) {
                lastLoadError = "mémoire insuffisante (${freeMb} Mo libres, seuil TV ${minSafeFreeMb} Mo)"
                _downloadStatusMessage.value = "Modèle « ${modelInfo.name} » bloqué pour protéger la TV : ${freeMb} Mo libres, ${minSafeFreeMb} Mo minimum recommandés. Aucun chargement natif lancé."
                Log.w(TAG, "Refus de chargement Sherpa: free=${freeMb}MB, threshold=${minSafeFreeMb}MB, model=${modelInfo.name}")
                return false
            }

            _downloadStatusMessage.value = "Chargement du modèle ${modelInfo.name}..."
            guardPrefs(context).edit().putString("loading_model", safeId).commit()
            val ok = loadRecognizerFromDirectory(modelDir, safeId)
            // Si l'utilisateur a désactivé la fonction pendant le chargement natif,
            // ne laissons pas le modèle lourd rester en RAM.
            if (ok && (!_isVoiceRecognitionActive.value || requestedModelId != safeId)) {
                unloadModel()
                return false
            }
            // Arrivé ici : pas de crash natif pendant le chargement
            guardPrefs(context).edit().remove("loading_model").apply()
            return ok
        } finally {
            loadingSinceMs = 0L
        }
    }

    fun startVoiceRecognition(context: Context) {
        initialize(context)
        _isVoiceRecognitionActive.value = true
        resetRecognitionState()
        val loaded = synchronized(recognizerLock) { currentRecognizer != null && isRecognizerReady }
        val wanted = expectedModelId()
        // IMPORTANT TV : ne pas relancer un chargement natif simplement parce qu'un réglage
        // de sous-titres appelle à nouveau applyGlobalMediaConfiguration().
        val sameLoadAlreadyRunning = requestedModelId == wanted && (loadModelJob?.isActive == true || loadMutex.isLocked)
        if (!loaded && !sameLoadAlreadyRunning) {
            setSourceLanguage(_selectedVoiceModelId.value, context)
        }
    }

    fun stopVoiceRecognition() {
        _isVoiceRecognitionActive.value = false
        resetRecognitionState()
        // Le modèle ONNX est la plus grosse allocation de la fonction de sous-titrage vocal.
        // Le conserver après désactivation n'apporte rien et peut faire tomber une TV 2 Go
        // lors d'un changement de chaîne/réglage. On libère donc RAM + buffers natifs.
        requestedModelId = null
        loadModelJob?.cancel()
        unloadModel()
    }

    fun resetRecognitionState() {
        lastPartialText = ""
        isResetRequested.set(true)
        synchronized(sampleLock) {
            sampleAccumulatorSize = 0
        }
        speechSegmentStartElapsedMs = 0L
        lastSherpaProgressMs = SystemClock.elapsedRealtime()
        while (audioProcessingChannel.tryReceive().isSuccess) { }
        pendingChunks.set(0)
        delayedEmitJob?.cancel()
        delayedEmitJob = null
        // Invalide tous les résultats encore en attente dans la ligne à retard
        synchronized(emitLock) {
            lastEmittedSequence = emitSequence.get()
        }
        autoClearJob?.cancel()
        autoClearJob = null
        _recognizedSpeechText.value = null
        _isSpeechDetected.value = false
        notifySpeechResult("")
    }

    fun flushAccumulator() {
        synchronized(sampleLock) {
            if (sampleAccumulatorSize > 0) {
                val chunk = sampleAccumulator.copyOf(sampleAccumulatorSize)
                val now = SystemClock.elapsedRealtime()
                val durationMs = (chunk.size * 1000L / SAMPLE_RATE).coerceAtLeast(1L)
                audioProcessingChannel.trySend(AudioChunk(chunk, now - durationMs, durationMs))
                sampleAccumulatorSize = 0
            }
        }
    }

    fun feedAudioPcm(pcmData: ByteArray, length: Int) {
        if (!_isVoiceRecognitionActive.value || length < 2) return

        val energy = calculateRmsEnergy(pcmData, length)
        if (energy > 25.0) {
            _isSpeechDetected.value = true
        }

        val totalSamples = length / 2
        val floatBlock = FloatArray(totalSamples)
        var sIdx = 0
        for (i in 0 until (length - 1) step 2) {
            val low = pcmData[i].toInt() and 0xFF
            val high = pcmData[i + 1].toInt()
            val s = ((high shl 8) or low).toShort()
            floatBlock[sIdx++] = s / 32768.0f
        }

        feedAudioSamples(floatBlock, totalSamples)
    }

    fun feedAudioSamples(samples: FloatArray, count: Int) {
        if (!_isVoiceRecognitionActive.value || count <= 0) return

        synchronized(sampleLock) {
            var srcOffset = 0
            var remaining = count
            lastAudioFeedTime = System.currentTimeMillis()

            while (remaining > 0) {
                val available = sampleAccumulator.size - sampleAccumulatorSize
                if (available <= 0) {
                    val chunk = sampleAccumulator.copyOf(sampleAccumulatorSize)
                    val now = SystemClock.elapsedRealtime()
                    val durationMs = (chunk.size * 1000L / SAMPLE_RATE).coerceAtLeast(1L)
                    audioProcessingChannel.trySend(AudioChunk(chunk, now - durationMs, durationMs))
                    sampleAccumulatorSize = 0
                }
                val toCopy = minOf(remaining, sampleAccumulator.size - sampleAccumulatorSize)
                if (toCopy <= 0) {
                    sampleAccumulatorSize = 0
                    continue
                }
                System.arraycopy(samples, srcOffset, sampleAccumulator, sampleAccumulatorSize, toCopy)
                sampleAccumulatorSize += toCopy
                srcOffset += toCopy
                remaining -= toCopy

                if (sampleAccumulatorSize >= 2400) { // 150ms de son @ 16kHz optimisé pour Android & Google TV
                    val chunk = sampleAccumulator.copyOf(sampleAccumulatorSize)
                    val now = SystemClock.elapsedRealtime()
                    val durationMs = (chunk.size * 1000L / SAMPLE_RATE).coerceAtLeast(1L)
                    if (audioProcessingChannel.trySend(AudioChunk(chunk, now - durationMs, durationMs)).isFailure) {
                        audioProcessingChannel.tryReceive() // Éviter l'accumulation pour latence 0
                        audioProcessingChannel.trySend(AudioChunk(chunk, now - durationMs, durationMs))
                    }
                    sampleAccumulatorSize = 0
                }
            }
        }
    }

    private fun calculateRmsEnergy(pcmData: ByteArray, length: Int): Double {
        if (length < 2) return 0.0
        var sumSquares = 0.0
        var count = 0
        var i = 0
        while (i < length - 1) {
            val low = pcmData[i].toInt() and 0xFF
            val high = pcmData[i + 1].toInt()
            val sample = ((high shl 8) or low).toShort().toDouble()
            sumSquares += (sample * sample)
            count++
            i += 4
        }
        if (count == 0) return 0.0
        return sqrt(sumSquares / count)
    }

    /**
     * Conditionnement acoustique : amplifie adaptativement les signaux vocaux faibles
     * et équilibre le spectre pour faire ressortir les consonnes douces et accents sans distorsion.
     */
    private fun applyAcousticNormalization(samples: FloatArray, count: Int) {
        if (count <= 0) return
        var sumSquares = 0.0
        for (i in 0 until count) {
            val s = samples[i]
            if (s.isNaN() || s.isInfinite()) {
                samples[i] = 0.0f
                continue
            }
            sumSquares += (s * s)
        }
        val rms = sqrt(sumSquares / count)
        if (rms.isNaN() || rms.isInfinite()) return
        diagLastRms = rms.toFloat()

        // Hystérésis : l'indicateur "parole détectée" retombe enfin quand le silence revient
        if (rms > 0.006) {
            _isSpeechDetected.value = true
        } else if (rms < 0.002 && _recognizedSpeechText.value == null) {
            _isSpeechDetected.value = false
        }

        val target = if (rms in 0.004..0.22) (0.24 / rms).toFloat().coerceIn(1.0f, 2.2f) else 1.0f
        // Descente rapide (évite la saturation), montée lente (évite le pompage / la remontée du bruit)
        agcGain += (target - agcGain) * (if (target < agcGain) 0.6f else 0.15f)
        if (agcGain <= 1.01f) return
        val gain = agcGain
        for (i in 0 until count) {
            val amplified = samples[i] * gain
            // Limiteur doux : linéaire jusqu'à 0.6 puis compression progressive.
            // L'ancien écrêtage brutal à 0.95 distordait la parole sur les passages forts (musique, jingles)
            // et faisait produire des mots absurdes au modèle.
            val mag = if (amplified < 0f) -amplified else amplified
            samples[i] = if (mag <= 0.6f) amplified else {
                val limited = 0.6f + 0.38f * Math.tanh(((mag - 0.6f) / 0.38f).toDouble()).toFloat()
                if (amplified < 0f) -limited else limited
            }
        }
    }

    private fun dispatchSpeechResult(text: String, isFinal: Boolean, targetElapsedMs: Long = 0L) {
        val seq = emitSequence.incrementAndGet()
        val manualOffset = _syncOffsetMs.value.toLong()
        val now = SystemClock.elapsedRealtime()
        val target = if (targetElapsedMs > 0L) {
            targetElapsedMs + manualOffset
        } else {
            now + manualOffset
        }
        val delayMs = (target - now).coerceAtLeast(0L)

        if (delayMs == 0L) {
            emitSpeechResultNow(seq, text, isFinal)
        } else {
            scope.launch(Dispatchers.Default) {
                delay(delayMs)
                emitSpeechResultNow(seq, text, isFinal)
            }
        }
    }

    private fun emitSpeechResultNow(seq: Long, text: String, isFinal: Boolean) {
        synchronized(emitLock) {
            if (seq <= lastEmittedSequence) return
            lastEmittedSequence = seq
        }
        lastEmittedIsFinal = isFinal
        _recognizedSpeechText.value = text
        notifySpeechResult(text)
        resetAutoClearTimer(text)
    }

    /**
     * Durée d'affichage adaptée à la lecture confortable sur TV (distance 2–3 m) :
     * ~10–12 caractères/seconde + marge généreuse.
     * 2,8 s de base + 90 ms par caractère, bornée entre 4 s et 16 s.
     * Objectif : laisser le temps de lire les phrases longues sur grand écran.
     */
    fun calculateIntelligentDisplayDurationMs(text: String): Long {
        if (text.isBlank()) return 4000L
        if (!_isIntelligentDurationEnabled.value) {
            return (_autoClearDelaySeconds.value * 1000L).coerceIn(4000L, 18000L)
        }
        val computed = 2800L + (text.trim().length * 90L)
        return computed.coerceIn(4000L, 16000L)
    }

    fun refreshAutoClearTimer(text: String) {
        if (text.isBlank()) return
        resetAutoClearTimer(text)
    }

    private fun resetAutoClearTimer(text: String) {
        autoClearJob?.cancel()
        val delayMs = calculateIntelligentDisplayDurationMs(text)
        autoClearJob = scope.launch(Dispatchers.Default) {
            delay(delayMs)
            _recognizedSpeechText.value = null
            _isSpeechDetected.value = false
            notifySpeechResult("")
        }
    }

    fun injectSimulationSpeech(text: String) {
        _isSpeechDetected.value = true
        lastEmittedIsFinal = true
        _recognizedSpeechText.value = text
        notifySpeechResult(text)
        resetAutoClearTimer(text)
    }

    private fun getModelInfoForLanguage(langCode: String): SherpaModelInfo {
        val clean = langCode.trim().lowercase()
        AVAILABLE_MODELS.find { it.id == clean || it.code == clean }?.let { return it }
        // Langue sans modèle dédié : utiliser le modèle prévu par la table allModels
        // (ex. "ru" -> modèle multilingue au lieu du modèle français).
        val mappedDir = allModels[clean]
        return AVAILABLE_MODELS.find { it.dirName == mappedDir } ?: AVAILABLE_MODELS.first()
    }

    private fun getModelDirectory(context: Context, modelInfo: SherpaModelInfo): File {
        val baseDir = File(context.filesDir, "sherpa-models")
        if (!baseDir.exists()) baseDir.mkdirs()
        return File(baseDir, modelInfo.dirName)
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 Mo"
        val mb = bytes.toDouble() / (1024.0 * 1024.0)
        return if (mb < 1.0) {
            String.format(java.util.Locale.US, "%.0f Ko", bytes.toDouble() / 1024.0)
        } else {
            String.format(java.util.Locale.US, "%.1f Mo", mb)
        }
    }

    private fun getExpectedFileSize(fileName: String, modelId: String): Long {
        return when {
            modelId == "ar" && fileName == "tokens.txt" -> 195_244L
            modelId == "ar" && fileName == "bpe.model" -> 476_049L
            modelId == "ar" && fileName.contains("encoder") -> 296_583_597L
            modelId == "ar" && fileName.contains("decoder") -> 33_837_085L
            modelId == "ar" && fileName.contains("joiner") -> 8_257_421L

            modelId == "fr" && fileName == "tokens.txt" -> 4_819L
            modelId == "fr" && fileName.contains("encoder") -> 126_655_903L
            modelId == "fr" && fileName.contains("decoder") -> 1_307_157L
            modelId == "fr" && fileName.contains("joiner") -> 259_572L

            modelId == "en" && fileName == "tokens.txt" -> 5_048L
            modelId == "en" && fileName.contains("encoder") -> 42_845_182L
            modelId == "en" && fileName.contains("decoder") -> 539_499L
            modelId == "en" && fileName.contains("joiner") -> 259_572L

            fileName.endsWith(".onnx") -> 20_000_000L
            fileName.endsWith(".txt") -> 5_000L
            fileName.endsWith(".model") -> 500_000L
            else -> 1_000_000L
        }
    }

    fun isModelInstalled(context: Context, model: SherpaModelInfo): Boolean {
        val dir = getModelDirectory(context, model)
        if (!dir.exists() || !dir.isDirectory) return false
        for (fileName in model.fileNames) {
            val file = File(dir, fileName)
            if (!file.exists()) return false
            val minExpected = when {
                fileName.contains("encoder") -> 20_000_000L
                fileName.contains("decoder") -> 400_000L
                fileName.contains("joiner") -> 200_000L
                fileName.endsWith(".txt") -> 500L
                fileName.endsWith(".model") -> 100_000L
                else -> 100L
            }
            if (file.length() < minExpected) return false
        }
        return true
    }

    suspend fun downloadAndExtractModel(context: Context, model: SherpaModelInfo): Boolean = withContext(Dispatchers.IO) {
        downloadMutex.withLock {
            _isDownloadingModel.value = true
            _downloadProgress.value = 0f
            _downloadStatusMessage.value = "Préparation du téléchargement (${model.name})..."

            val dir = getModelDirectory(context, model)
            if (!dir.exists()) dir.mkdirs()

            try {
                val totalModelBytes = model.fileNames.sumOf { getExpectedFileSize(it, model.id) }.coerceAtLeast(1L)
                var completedFilesBytes = 0L

                for (fileName in model.fileNames) {
                    val destFile = File(dir, fileName)
                    val expectedSize = getExpectedFileSize(fileName, model.id)
                    val minExpected = when {
                        fileName.endsWith(".onnx") -> 100_000L
                        fileName.endsWith(".txt") -> 100L
                        fileName.endsWith(".model") -> 10_000L
                        else -> 50L
                    }

                    // Si le fichier existe déjà et est valide, le compter comme complété
                    if (destFile.exists() && destFile.length() >= minExpected) {
                        completedFilesBytes += destFile.length()
                        val initialProgress = (completedFilesBytes.toDouble() / totalModelBytes.toDouble()).toFloat().coerceIn(0f, 1f)
                        _downloadProgress.value = initialProgress
                        continue
                    } else if (destFile.exists()) {
                        destFile.delete() // Nettoyer un ancien fichier corrompu
                    }

                    val tmpFile = File(dir, "$fileName.tmp")
                    val candidateUrls = listOf(
                        model.baseUrl + fileName,
                        model.baseUrl + fileName + "?download=true",
                        model.baseUrl.replace("https://huggingface.co/", "https://hf-mirror.com/") + fileName
                    ).distinct()

                    var fileCompleted = false
                    var lastException: Exception? = null

                    for (attempt in 1..4) {
                        val currentUrl = candidateUrls[(attempt - 1) % candidateUrls.size]
                        try {
                            var existingBytes = if (tmpFile.exists()) tmpFile.length() else 0L

                            val reqBuilder = Request.Builder()
                                .url(currentUrl)
                                .header("User-Agent", "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36")
                                .header("Accept", "*/*")

                            if (existingBytes > 0L) {
                                reqBuilder.header("Range", "bytes=$existingBytes-")
                            }

                            val req = reqBuilder.build()
                            httpClient.newCall(req).execute().use { response ->
                                if (response.code == 416) {
                                    tmpFile.delete()
                                    existingBytes = 0L
                                    throw Exception("HTTP 416 Range réinitialisé")
                                }
                                if (!response.isSuccessful) {
                                    throw Exception("HTTP ${response.code} pour $currentUrl")
                                }

                                val body = response.body ?: throw Exception("Réponse vide pour $currentUrl")
                                val isAppend = response.code == 206
                                if (!isAppend) {
                                    existingBytes = 0L
                                }

                                val remoteRemaining = body.contentLength()
                                val fileTotal = if (remoteRemaining > 0) existingBytes + remoteRemaining else expectedSize

                                FileOutputStream(tmpFile, isAppend).use { output ->
                                    body.byteStream().use { input ->
                                        val buffer = ByteArray(65536)
                                        var bytesRead: Int
                                        var currentFileDownloaded = existingBytes
                                        var lastUpdate = 0L

                                        while (input.read(buffer).also { bytesRead = it } != -1) {
                                            output.write(buffer, 0, bytesRead)
                                            currentFileDownloaded += bytesRead
                                            val now = System.currentTimeMillis()
                                            if (now - lastUpdate > 150L) {
                                                lastUpdate = now
                                                val overallBytes = completedFilesBytes + currentFileDownloaded
                                                val progress = (overallBytes.toDouble() / totalModelBytes.toDouble()).toFloat().coerceIn(0f, 0.99f)
                                                _downloadProgress.value = progress
                                                val pct = (progress * 100).toInt()
                                                _downloadStatusMessage.value = "Téléchargement $fileName : ${formatBytes(currentFileDownloaded)} / ${formatBytes(fileTotal)} ($pct%)"
                                            }
                                        }
                                    }
                                }
                            }

                            if (tmpFile.length() < minExpected) {
                                tmpFile.delete()
                                throw Exception("Fichier incomplet (${tmpFile.length()} octets)")
                            }

                            if (destFile.exists()) destFile.delete()
                            var renamed = tmpFile.renameTo(destFile)
                            if (!renamed) {
                                try {
                                    tmpFile.inputStream().use { inp ->
                                        destFile.outputStream().use { outp ->
                                            inp.copyTo(outp)
                                        }
                                    }
                                    tmpFile.delete()
                                    renamed = true
                                } catch (e: Exception) {
                                    renamed = false
                                }
                            }

                            if (renamed) {
                                fileCompleted = true
                                completedFilesBytes += destFile.length()
                                break
                            } else {
                                throw Exception("Échec de sauvegarde finale pour $fileName")
                            }
                        } catch (e: Exception) {
                            lastException = e
                            Log.w(TAG, "Tentative $attempt/4 pour $fileName a échoué: ${e.message}")
                            if (attempt < 4) {
                                _downloadStatusMessage.value = "Reprise automatique $fileName ($attempt/4)..."
                                delay(1500L * attempt)
                            }
                        }
                    }

                    if (!fileCompleted) {
                        throw lastException ?: Exception("Échec du téléchargement pour $fileName après 4 tentatives")
                    }
                }

                _downloadProgress.value = 1f
                _downloadStatusMessage.value = "Modèle ${model.name} prêt !"
                Log.d(TAG, "[dlog] Sherpa-ONNX modèle téléchargé avec succès: ${model.id}")
                true
            } catch (e: Exception) {
                Log.e(TAG, "Erreur téléchargement modèle ${model.id}: ${e.message}", e)
                _downloadStatusMessage.value = "Erreur téléchargement: ${e.message}"
                false
            } finally {
                _isDownloadingModel.value = false
            }
        }
    }

    fun deleteModel(context: Context, model: SherpaModelInfo): Boolean {
        return try {
            synchronized(recognizerLock) {
                if (currentLoadedLanguage == model.id) {
                    try {
                        if (isStreamValid(currentStream)) currentStream?.release()
                    } catch (t: Throwable) { }
                    currentStream = null
                    try {
                        if (isRecognizerValid(currentRecognizer)) currentRecognizer?.release()
                    } catch (t: Throwable) { }
                    currentRecognizer = null
                    currentLoadedLanguage = null
                }
            }
            unblockModel(context, model.id)
            val dir = getModelDirectory(context, model)
            if (dir.exists()) {
                dir.deleteRecursively()
            } else true
        } catch (e: Exception) {
            Log.e(TAG, "Erreur suppression modèle: ${e.message}")
            false
        }
    }

    /**
     * Nettoie les artefacts de tokenisation SentencePiece et BPE pour le français, l'arabe et le multilingue.
     */
    fun cleanRecognizedSpeech(raw: String): String {
        if (raw.isBlank()) return ""
        var s = raw
            .replace("\u2581", " ") // Symbole de séparation de mot SentencePiece
            .replace(" ", " ")
            .replace("@@", "") // Connecteur BPE
            .replace(Regex("<0x[0-9A-Fa-f]{2}>"), "") // Éliminer les fragments d'octets bruts
            .replace(Regex("\\s+"), " ")
            .trim()
        // Bruit / musique : une seule lettre isolée n'est jamais un sous-titre utile
        if (s.count { it.isLetter() } < 2) return ""
        return collapseRepeatedWords(s)
    }

    /** « de de de de de » (artefact typique sur musique/bruit) -> « de de » : 2 répétitions consécutives au maximum. */
    private fun collapseRepeatedWords(text: String): String {
        val words = text.split(' ')
        if (words.size < 4) return text
        val out = ArrayList<String>(words.size)
        var run = 0
        for (w in words) {
            if (out.isNotEmpty() && out[out.size - 1].equals(w, ignoreCase = true)) {
                run++
                if (run >= 2) continue
            } else {
                run = 0
            }
            out.add(w)
        }
        return out.joinToString(" ")
    }

    private fun loadRecognizerFromDirectory(modelDir: File, languageCode: String): Boolean {
        try {
            val tokensFile = File(modelDir, "tokens.txt")
            val files = modelDir.listFiles().orEmpty()
            val encoderFile = files.find { it.name.contains("encoder") && it.name.endsWith(".onnx") }
            val decoderFile = files.find { it.name.contains("decoder") && it.name.endsWith(".onnx") }
            val joinerFile = files.find { it.name.contains("joiner") && it.name.endsWith(".onnx") }
            val bpeFile = File(modelDir, "bpe.model").takeIf { it.exists() }

            if (encoderFile == null || decoderFile == null || joinerFile == null || !tokensFile.exists()) {
                Log.w(TAG, "Modèle Sherpa incomplet dans $modelDir")
                _downloadStatusMessage.value = "Modèle incomplet, téléchargement requis"
                lastLoadError = "modèle incomplet"
                return false
            }

            if (encoderFile.length() < 1_000_000L || decoderFile.length() < 100_000L || joinerFile.length() < 50_000L || tokensFile.length() < 50L) {
                Log.w(TAG, "Fichiers ONNX invalides ou incomplets dans $modelDir")
                _downloadStatusMessage.value = "Fichiers corrompus, retéléchargement requis"
                lastLoadError = "fichiers corrompus"
                return false
            }

            // Libérer l'ancien modèle AVANT d'en créer un nouveau : sinon les deux coexistent en mémoire
            // (FR ~130 Mo + AR ~340 Mo) et une TV à 2 Go tue l'application.
            synchronized(recognizerLock) {
                isRecognizerReady = false
                isStreamReady = false
                try { currentStream?.release() } catch (t: Throwable) { }
                try { currentRecognizer?.release() } catch (t: Throwable) { }
                currentStream = null
                currentRecognizer = null
                currentLoadedLanguage = null
            }
            System.gc()

            val transducerConfig = OnlineTransducerModelConfig(
                encoder = encoderFile.absolutePath,
                decoder = decoderFile.absolutePath,
                joiner = joinerFile.absolutePath
            )

            val liveTvEndpointConfig = EndpointConfig(
                rule1 = com.k2fsa.sherpa.onnx.EndpointRule(mustContainNonSilence = false, minTrailingSilence = 1.2f, minUtteranceLength = 0.0f),
                rule2 = com.k2fsa.sherpa.onnx.EndpointRule(mustContainNonSilence = true, minTrailingSilence = 0.7f, minUtteranceLength = 0.0f),
                // Coupure forcée à 25 s (avant 10 s) : une phrase longue n'est plus tronquée + remise à zéro en plein milieu
                rule3 = com.k2fsa.sherpa.onnx.EndpointRule(mustContainNonSilence = false, minTrailingSilence = 0.0f, minUtteranceLength = 25.0f)
            )

            // 1 thread sur les petits SoC (2 coeurs), 2 threads dès 4 coeurs : un seul thread int8 sur un
            // Cortex-A53/A55 de boîtier Google TV décode parfois moins vite que le temps réel
            // (l'audio en retard était alors jeté par le canal DROP_OLDEST -> mots perdus).
            // Plus de threads = calcul plus rapide que le temps réel (les poids restent partagés, peu de RAM en plus).
            val cores = Runtime.getRuntime().availableProcessors()
            val byCores = when {
                cores >= 6 -> 4
                cores >= 4 -> 3
                cores >= 2 -> 2
                else -> 1
            }
            // Arabe (~340 Mo) : 1 seul thread -> moins de mémoire de travail, évite le plantage natif sur TV.
            // Petit modèle (anglais 20M) : 2 threads max, plus ne fait que gaspiller du CPU (attente active).
            val tvOrLowRam = isTvOrLowRam(appContext)
            val optimalThreads = when {
                languageCode == "ar" -> 1
                tvOrLowRam -> minOf(2, byCores)
                languageCode == "en" -> minOf(2, byCores)
                else -> byCores
            }

            // Dans Sherpa-ONNX 1.10+, les modèles zipformer utilisent zipformer2
            val candidateTypes = if (bpeFile != null && bpeFile.exists()) {
                listOf("zipformer2", "", "zipformer")
            } else {
                listOf("", "zipformer2", "zipformer")
            }
            var testRecognizer: OnlineRecognizer? = null
            var testStream: OnlineStream? = null
            var lastInitError: String? = null

            for (typeCandidate in candidateTypes) {
                try {
                    val mConfig = OnlineModelConfig(
                        transducer = transducerConfig,
                        tokens = tokensFile.absolutePath,
                        numThreads = optimalThreads,
                        debug = false,
                        provider = "cpu",
                        modelType = typeCandidate,
                        bpeVocab = ""
                    )
                    val rConfig = OnlineRecognizerConfig(
                        featConfig = FeatureConfig(sampleRate = SAMPLE_RATE, featureDim = 80),
                        modelConfig = mConfig,
                        endpointConfig = liveTvEndpointConfig,
                        enableEndpoint = true,
                        // Recherche par faisceau (4 hypothèses) : moins de mots faux que le décodage glouton.
                        // Réservé aux appareils d'au moins 4 coeurs (coût CPU supérieur) et aux modèles légers.
                        decodingMethod = if (shouldUseBeamSearch(languageCode, cores)) "modified_beam_search" else "greedy_search",
                        maxActivePaths = 4
                    )
                    val rec = OnlineRecognizer(config = rConfig)
                    val str = rec.createStream()
                    testRecognizer = rec
                    testStream = str
                    Log.d(TAG, "[dlog] Sherpa-ONNX initialisé avec succès ($languageCode, threads=$optimalThreads, modelType='$typeCandidate')")
                    break
                } catch (t: Throwable) {
                    Log.w(TAG, "Tentative init Sherpa avec modelType='$typeCandidate' a échoué: ${t.message}")
                    lastInitError = "${t.javaClass.simpleName}: ${t.message}"
                }
            }

            if (testRecognizer == null || testStream == null) {
                throw Exception("Échec création OnlineRecognizer Sherpa-ONNX (${lastInitError ?: "?"})")
            }

            synchronized(recognizerLock) {
                isRecognizerReady = false
                isStreamReady = false
                try { currentStream?.release() } catch (t: Throwable) { }
                try { currentRecognizer?.release() } catch (t: Throwable) { }
                currentRecognizer = testRecognizer
                currentStream = testStream
                currentLoadedLanguage = languageCode
                isRecognizerReady = true
                isStreamReady = true
                lastSherpaProgressMs = SystemClock.elapsedRealtime()
            }

            _isVoiceRecognitionActive.value = true
            GlobalDebugSystem.logStateChange("SherpaLoadedModel", "none", languageCode)
            Log.d(TAG, "[dlog] Sherpa-ONNX prêt: $languageCode")
            lastLoadError = null
            _downloadStatusMessage.value = "Modèle vocal chargé ✓ ($languageCode)"
            return true
        } catch (t: Throwable) {
            Log.e(TAG, "Erreur initialisation OnlineRecognizer Sherpa: ${t.message}", t)
            lastLoadError = t.message ?: t.javaClass.simpleName
            _downloadStatusMessage.value = "Erreur init Sherpa: ${t.message}"
            return false
        }
    }

    /**
     * Crée un AudioProcessor Media3 qui capture le flux PCM sans couper ni altérer l'audio d'origine.
     */
    fun createMedia3AudioProcessor(): AudioProcessor {
        return SherpaCaptureAudioProcessor()
    }

    /**
     * Filtre passe-bas biquad (Butterworth 2e ordre) utilisé comme filtre anti-repliement
     * avant la décimation vers 16 kHz.
     */
    private class Biquad {
        private var b0 = 1.0
        private var b1 = 0.0
        private var b2 = 0.0
        private var a1 = 0.0
        private var a2 = 0.0
        private var x1 = 0.0
        private var x2 = 0.0
        private var y1 = 0.0
        private var y2 = 0.0

        fun setLowPass(cutoffHz: Double, sampleRate: Double) {
            val w0 = 2.0 * Math.PI * cutoffHz / sampleRate
            val cosW = Math.cos(w0)
            val alpha = Math.sin(w0) / (2.0 * 0.70710678)
            val a0 = 1.0 + alpha
            b0 = (1.0 - cosW) / 2.0 / a0
            b1 = (1.0 - cosW) / a0
            b2 = b0
            a1 = -2.0 * cosW / a0
            a2 = (1.0 - alpha) / a0
            reset()
        }

        fun setHighPass(cutoffHz: Double, sampleRate: Double) {
            val w0 = 2.0 * Math.PI * cutoffHz / sampleRate
            val cosW = Math.cos(w0)
            val alpha = Math.sin(w0) / (2.0 * 0.70710678)
            val a0 = 1.0 + alpha
            b0 = (1.0 + cosW) / 2.0 / a0
            b1 = -(1.0 + cosW) / a0
            b2 = b0
            a1 = -2.0 * cosW / a0
            a2 = (1.0 - alpha) / a0
            reset()
        }

        fun reset() {
            x1 = 0.0
            x2 = 0.0
            y1 = 0.0
            y2 = 0.0
        }

        fun process(x: Float): Float {
            val xd = x.toDouble()
            val y = b0 * xd + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1
            x1 = xd
            y2 = y1
            y1 = y
            return y.toFloat()
        }
    }

    /**
     * Processeur Audio Media3 : copie l'audio tel quel vers la sortie (aucune altération du son)
     * et alimente Sherpa-ONNX en mono 16 kHz.
     *
     * Correctif qualité : l'ancienne version décimait 48 kHz -> 16 kHz en prenant 1 échantillon sur 3
     * SANS filtre, ce qui replie les hautes fréquences (sifflantes, bruit) dans la bande de la voix
     * et dégrade nettement la reconnaissance. Ici : downmix -> passe-bas 7 kHz (2 x biquad) ->
     * interpolation linéaire avec état conservé d'un buffer à l'autre (pas de rupture de phase).
     * Gère PCM 8/16/24/32 bits et Float, mono, stéréo et 5.1/7.1 (canal central privilégié).
     */
    private class SherpaCaptureAudioProcessor : BaseAudioProcessor() {
        private var inputSampleRate: Int = 48000
        private var inputChannelCount: Int = 2
        private var inputEncoding: Int = C.ENCODING_PCM_16BIT
        private var bytesPerSample: Int = 2
        private val targetSampleRate = 16000

        private val lowPassA = Biquad()
        private val lowPassB = Biquad()
        private val highPass = Biquad()
        private var useLowPass = false
        private var step = 3.0
        private var readPos = 0.0
        private var prevSample = 0f
        private var monoBuffer = FloatArray(8192)
        private val outChunk = FloatArray(1600) // 100 ms @ 16 kHz
        private var outSize = 0

        override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
            if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT &&
                inputAudioFormat.encoding != C.ENCODING_PCM_FLOAT &&
                inputAudioFormat.encoding != C.ENCODING_PCM_24BIT &&
                inputAudioFormat.encoding != C.ENCODING_PCM_32BIT &&
                inputAudioFormat.encoding != C.ENCODING_PCM_8BIT
            ) {
                diagFormat = "format audio NON PCM (passthrough ? encodage=${inputAudioFormat.encoding})"
                return AudioProcessor.AudioFormat.NOT_SET
            }
            inputEncoding = inputAudioFormat.encoding
            inputSampleRate = if (inputAudioFormat.sampleRate > 0) inputAudioFormat.sampleRate else 48000
            inputChannelCount = if (inputAudioFormat.channelCount > 0) inputAudioFormat.channelCount else 2
            diagFormat = "${inputSampleRate} Hz, ${inputChannelCount} ch, " + when (inputEncoding) {
                C.ENCODING_PCM_16BIT -> "PCM16"
                C.ENCODING_PCM_FLOAT -> "PCM float"
                C.ENCODING_PCM_24BIT -> "PCM24"
                C.ENCODING_PCM_32BIT -> "PCM32"
                else -> "PCM8"
            }
            bytesPerSample = when (inputEncoding) {
                C.ENCODING_PCM_FLOAT, C.ENCODING_PCM_32BIT -> 4
                C.ENCODING_PCM_24BIT -> 3
                C.ENCODING_PCM_8BIT -> 1
                else -> 2
            }
            step = inputSampleRate.toDouble() / targetSampleRate.toDouble()
            useLowPass = inputSampleRate > targetSampleRate
            highPass.setHighPass(90.0, inputSampleRate.toDouble())
            if (useLowPass) {
                val cutoff = minOf(7000.0, inputSampleRate * 0.45)
                lowPassA.setLowPass(cutoff, inputSampleRate.toDouble())
                lowPassB.setLowPass(cutoff, inputSampleRate.toDouble())
            }
            resetState()
            return inputAudioFormat
        }

        override fun onFlush() {
            resetState()
        }

        override fun onReset() {
            resetState()
        }

        private fun resetState() {
            readPos = 0.0
            prevSample = 0f
            outSize = 0
            lowPassA.reset()
            lowPassB.reset()
            highPass.reset()
        }

        override fun queueInput(inputBuffer: ByteBuffer) {
            val remaining = inputBuffer.remaining()
            if (remaining == 0) return
            diagInputCalls++

            // Vue indépendante pour Sherpa : inputBuffer reste intact pour la sortie
            val sherpaView: ByteBuffer? = if (_isVoiceRecognitionActive.value) {
                inputBuffer.duplicate().order(inputBuffer.order())
            } else null

            // Priorité absolue : l'audio d'origine part immédiatement vers la sortie
            val out = replaceOutputBuffer(remaining)
            out.put(inputBuffer)
            out.flip()

            if (sherpaView != null) {
                try {
                    captureForSherpa(sherpaView)
                } catch (t: Throwable) {
                    // Ne jamais casser le pipeline ExoPlayer
                }
            }
        }

        private fun sampleAt(view: ByteBuffer, offset: Int): Float {
            return when (inputEncoding) {
                C.ENCODING_PCM_FLOAT -> view.getFloat(offset)
                C.ENCODING_PCM_32BIT -> view.getInt(offset) / 2147483648.0f
                C.ENCODING_PCM_24BIT -> {
                    val raw = (view.get(offset + 2).toInt() shl 16) or
                        ((view.get(offset + 1).toInt() and 0xFF) shl 8) or
                        (view.get(offset).toInt() and 0xFF)
                    raw / 8388608.0f
                }
                C.ENCODING_PCM_8BIT -> ((view.get(offset).toInt() and 0xFF) - 128) / 128.0f
                else -> view.getShort(offset) / 32768.0f
            }
        }

        private fun downmixFrame(view: ByteBuffer, offset: Int, channels: Int): Float {
            if (channels == 1) return sampleAt(view, offset)
            val l = sampleAt(view, offset)
            val r = sampleAt(view, offset + bytesPerSample)
            if (channels >= 6) {
                // 5.1 / 7.1 : ordre Android FL, FR, FC, LFE... -> le dialogue est dans le canal central
                val c = sampleAt(view, offset + 2 * bytesPerSample)
                return c * 0.5f + (l + r) * 0.25f
            }
            return (l + r) * 0.5f
        }

        private fun pushSample(v: Float) {
            outChunk[outSize++] = if (v > 1f) 1f else if (v < -1f) -1f else v
            if (outSize >= outChunk.size) {
                enqueueChunk(outChunk.copyOf(outSize))
                outSize = 0
            }
        }

        private fun captureForSherpa(view: ByteBuffer) {
            val channels = inputChannelCount.coerceIn(1, 8)
            val bytesPerFrame = channels * bytesPerSample
            if (bytesPerFrame <= 0) return
            val base = view.position()
            val frames = (view.limit() - base) / bytesPerFrame
            if (frames <= 0) return
            if (monoBuffer.size < frames) monoBuffer = FloatArray(frames + 1024)
            val mono = monoBuffer

            // 1. Downmix mono + filtre anti-repliement
            var off = base
            for (f in 0 until frames) {
                var m = downmixFrame(view, off, channels)
                if (m.isNaN() || m.isInfinite()) m = 0f
                m = highPass.process(m)
                if (useLowPass) m = lowPassB.process(lowPassA.process(m))
                mono[f] = m
                off += bytesPerFrame
            }

            // 2. Rééchantillonnage linéaire vers 16 kHz (position fractionnaire conservée entre buffers)
            var t = readPos
            val last = frames - 1
            while (true) {
                val i0 = Math.floor(t).toInt() // t >= -1 ; i0 == -1 -> échantillon précédent
                if (i0 + 1 > last) break
                val frac = (t - i0).toFloat()
                val a = if (i0 < 0) prevSample else mono[i0]
                val b = mono[i0 + 1]
                pushSample(a + (b - a) * frac)
                t += step
            }
            readPos = t - frames
            prevSample = mono[last]
        }
    }
}
